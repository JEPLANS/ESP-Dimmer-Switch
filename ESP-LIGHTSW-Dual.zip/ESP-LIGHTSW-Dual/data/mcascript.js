function GVLe(p1) {
 return encodeURIComponent(document.getElementById(p1).value);
}
function GVLc(p1) {
 return document.getElementById(p1).value;
}
function AddToMac() {
 
 var lines=GVLc("Fdata").split("\n");
 lines[0]=GVLc("dscrp")+"\n";
 lines.length;
 var pst="";
 var ed=0;
 var lstval="";
 var i;
	for (i = 0; i < lines.length; i++) {
	  if (lines[i].length>2){
		if (lines[i].indexOf(GVLe("Switch"))>-1) {
		  
		  ed=1;
		}else {
			pst += lines[i] + "\n";
			}
	  }
	}
 if (ed==0){
 if (GVLe("st2")=="4") {
    lstval="&TA="+GVLe("3val");
 }
  if (GVLe("st2")=="1") {
    lstval="&st3="+GVLe("3val");
 }
 pst=pst+"http://"+GVLe("Switch")+"/Activate?st2="+GVLe("st2")+lstval+ "\n";
 }
 document.getElementById("Fdata").innerHTML = pst; 
}





