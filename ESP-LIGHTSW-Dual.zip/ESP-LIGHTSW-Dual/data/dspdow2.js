function tempGraph(vals,clr1,clr2,clr3,prct,lbf) {
var lsttx=0;
var tmx=0;
var tmn=200000;
var h=vals.split(","), i;
var smpls=(+h[0])+0;
var csmpl=(+h[smpls+1]);
var dy=['','Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
var ylbl=h[smpls+3];
var titl=dy[h[smpls+2]];
var c=document.getElementById("d"+h[smpls+2]);
var cw=c.width;
var ch=c.height;
var ctx=c.getContext("2d");
ctx.clearRect(0, 0, cw, ch); 
ctx.fillStyle="#DFDFDF"; 
ctx.fillRect(44,39,cw-78,202);
ctx.beginPath();
ctx.rect(44,39,cw-78,202); 
ctx.stroke(); 
var grd=ctx.createLinearGradient(0,ch,0,0);
grd.addColorStop(1,clr1);
grd.addColorStop(0,clr2);
var grd2=ctx.createLinearGradient(0,ch,0,0);
grd2.addColorStop(1,clr3);
grd2.addColorStop(0,clr3);

for (i=1;i<smpls+1;i++) {
 if ((h[i]*100)>tmx) {tmx=(h[i]*100);}
 if ((h[i]*100)<tmn) {tmn=(h[i]*100);}
 }

tmn=tmn-200;
tf=2;
if (prct==1) {
 tmx=100*100;
 tmn=0;
 tf=0;
} 
if (prct==2) {tmn=0;}
ctx.font="12px Georgia";
ctx.fillStyle="#000000";
ctx.fillText((tmx/100).toFixed(tf),5,40);
ctx.fillText(((((tmx-tmn)/2)+tmn)/100).toFixed(tf),5,140);
ctx.fillText((tmn/100).toFixed(tf),5,240);
var tw=ctx.measureText(ylbl).width;
ctx.fillText(ylbl,cw/2-tw/2,ch-5);

for (i=0;i<smpls;i++) {
 var j=i+1;
 var brw=(cw-80)/smpls;
 var ssum= +ssum + +h[j];
 var plvl=rmap((h[j]*100),tmn,tmx,0, 200);
 if (j==csmpl+1) {
  ctx.font="20px Georgia";
  ctx.fillStyle="#000000";
  var txt=titl;
  tw=ctx.measureText(txt).width;
  ctx.fillText(txt,cw/2-tw/2,25);
  ctx.fillStyle = grd2;
 } else {
  ctx.fillStyle = grd;
 }
 ctx.fillRect(i*brw+45,240-plvl,brw,200-(200-plvl));
 if ( j>lsttx+60 ) {
  lsttx=j-1;
  ctx.fillStyle="#000000";
  ctx.font="10px Georgia";
 switch (lbf){
 case 1:
  lbt=dy[i];
  break;
 case 2:
  lbt=mh[i];
  break;
 default: 
  lbt=i/60;
 } 
  tw=ctx.measureText(lbt).width;
  ctx.fillText(lbt,i*brw+45+(brw/2-tw/2),252);
  ctx.font="12px  Arial";
  dtx=Math.round(h[j]);
  tw=ctx.measureText(dtx).width;
  if (brw>tw){
   ctx.fillStyle="#C0B0B0";
   ctx.fillText(dtx,i*brw+45+(brw/2-tw/2),235);
  }
 }
}
}






