function GetEvent() { JEPost("GetEvent","","EventTable"); }
function DelEvt(devt) { JEPost("DelEvent","delevt="+devt,"EventTable"); }
function AddEvent() {
 var pst="tmin="+GVL("tmin")+"&thr="+GVL("thr")+"&tday="+GVL("tday")+"&st2="+GVL("st2")+"&st3="+GVL("ev3");
 JEPost("AddEvent","tmin="+GVL("tmin")+"&thr="+GVL("thr")+"&tday="+GVL("tday")+"&st2="+GVL("st2")+"&st3="+GVL("ev3")+"&st4="+GVL("st4"),"EventTable");}

function OnE(devt) {JEPost("OnE","OnE="+devt,"NoSet");}
document.addEventListener("DOMContentLoaded", function() {
 GStts(1);
 GStts(2);
 shoDim();
 var wkdy = new Array(7);
 wkdy[0]="ALL";wkdy[1]="SUN";wkdy[2]="MON";wkdy[3]="TUE";wkdy[4]="WED";wkdy[5]="THU";wkdy[6]="FRI";
 wkdy[7]="SAT";wkdy[8]="WDAY";wkdy[9]="WEND";
 var TPk ="<table><tr><th>Day<th>Time<th>Mode<th>SW<th>Add</tr><tr><TD>"
 TPk=TPk+"<Select id=tday name=tday>";
 for (i = 0; i < 9; i++) {TPk=TPk+"<option value="+i+">"+wkdy[i];}
 TPk = TPk+"</Select>";
 TPk = TPk+"<td><Select id=thr name=thr>";
 TPk=TPk+"<option value=25>Dawn<option value=26>Dusk";
 var plval=0;
 var d = new Date();
 var n = d.getHours();
 var slflg="";
 for (i = 0; i < 24; i++) { 
 slflg="";
   if (i<10) {plval="0";} else {plval="";}
 if (i==n) {slflg="selected";}
   TPk=TPk+"<option "+slflg+">"+plval+i;
 }
 TPk=TPk+"</Select>:<Select id=tmin name=tmin>";
 n = d.getMinutes();
 for (i = 0; i < 60; i++) {
   slflg="";
 if (i==n) {slflg="selected";}
 if (i<10) {plval="0";} else {plval="";}
   TPk=TPk+"<option "+slflg+">"+plval+i;
 }
 document.getElementById("tpick").innerHTML=TPk+"</Select><td><SELECT id=st2 name=st2><OPTION value=0 selected>Off<OPTION value=1 >On</SELECT><TD><SELECT id=st4 name=st4><OPTION selected>1<OPTION>2</SELECT><TD><button onclick=\"AddEvent()\">+</button></tr></table><p>";
 GetEvent();
 });














