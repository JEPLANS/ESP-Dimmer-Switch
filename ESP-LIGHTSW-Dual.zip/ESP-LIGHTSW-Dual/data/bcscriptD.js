function JEPost(pdest,pdata,pele) {
  var xhttp;
  if (window.XMLHttpRequest) { xhttp = new XMLHttpRequest();} else { xhttp = new ActiveXObject("Microsoft.XMLHTTP"); }
  xhttp.onreadystatechange = function() { if (this.readyState == 4 && this.status == 200) { if(pele != "NoSet"){
  var trTx=this.responseText;
  document.getElementById(pele).innerHTML = trTx; 
 if (trTx.search("On:")!=-1 || trTx=="On"){
 document.getElementById(pele).classList.remove( "swOff");
 document.getElementById(pele).classList.add( "swOn");
 document.getElementById("st3").value=trTx.substring(3);
 }
 if (trTx.search("Off:")!=-1 || trTx=="Off"){
 document.getElementById(pele).classList.remove( "swOn");
 document.getElementById(pele).classList.add( "swOff");
 document.getElementById("st3").value="0";
 }
  
  } } };
  xhttp.open("POST", pdest, true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send(pdata);
}
function GVL(p1) {
var myEle = document.getElementById(p1);
if(myEle){return myEle.value;} else { return ""; }
}

function Switch() { JEPost("Activate","st2="+GVL("st2")+"&st3="+GVL("st3")+"&sw="+GVL("wsw"),"results");}
function TSwitch(ac,tsw) { JEPost("Activate","st2="+ac+"&st3="+GVL("st3")+"&sw="+tsw,"results"+tsw);}
function OSwitch(ac,tsw) { JEPost("Activate","st2="+ac+"&st3=100&sw="+tsw,"results"+tsw);}

function shoDim() {
  var y = document.getElementById("dh1");
  var x = document.getElementById("dh2");
 if ( GVL("swm")=="1") {
  x.style.display = "none";
  y.style.display = "none";
 } else {
  x.style.display = "block";
  y.style.display = "block";
 }
}
function GStts(tsw){
  JEPost("Status","?v=0&sw="+tsw,"results"+tsw);
}



document.addEventListener("DOMContentLoaded", function() {
 GStts(1);
 GStts(2);
 shoDim();
});

















