function JEPost(pdest,pdata,pele) {
  var xhttp;
  if (window.XMLHttpRequest) { xhttp = new XMLHttpRequest();} else { xhttp = new ActiveXObject("Microsoft.XMLHTTP"); }
  xhttp.onreadystatechange = function() { if (this.readyState == 4 && this.status == 200) { if(pele != "NoSet"){
  var trTx=this.responseText;
  document.getElementById(pele).innerHTML = trTx; 
 if (trTx.search("On:")!=-1 || trTx=="On"){
 document.getElementById(pele).classList.remove( "swOff");
 document.getElementById(pele).classList.add( "swOn");
 document.getElementById("st3").value=trTx.substring(3);
 }
 if (trTx.search("Off:")!=-1 || trTx=="Off"){
 document.getElementById(pele).classList.remove( "swOn");
 document.getElementById(pele).classList.add( "swOff");
 document.getElementById("st3").value="0";
 }
  
  } } };
  xhttp.open("POST", pdest, true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send(pdata);
}

function GVL(p1) {
var myEle = document.getElementById(p1);
if(myEle){return myEle.value;} else { return ""; }
}

function shoDim() {
  var y = document.getElementById("dh1");
  var x = document.getElementById("dh2");
 if ( GVL("swm")=="1") {
  x.style.display = "none";
  y.style.display = "none";
 } else {
  x.style.display = "block";
  y.style.display = "block";
 }
}

function Switch() { JEPost("Activate","st2="+GVL("st2")+"&st3="+GVL("st3")+"&sw="+GVL("wsw"),"results");}
function TSwitch(ac) { JEPost("Activate","st2="+ac+"&st3="+GVL("st3")+"&sw="+GVL("wsw"),"results");}
function OSwitch(ac) { JEPost("Activate","st2="+ac+"&st3=100&sw="+GVL("wsw"),"results");}

function GStts(){
  JEPost("Status","?v=0&sw="+GVL("wsw"),"results");
}

function GetEvent() { JEPost("GetEvent","","EventTable"); }
function DelEvt(devt) { JEPost("DelEvent","delevt="+devt,"EventTable"); }
function AddEvent() {
 var pst="tmin="+GVL("tmin")+"&thr="+GVL("thr")+"&tday="+GVL("tday")+"&st2="+GVL("st2")+"&st3="+GVL("ev3");
 JEPost("AddEvent","tmin="+GVL("tmin")+"&thr="+GVL("thr")+"&tday="+GVL("tday")+"&st2="+GVL("st2")+"&st3="+GVL("ev3"),"EventTable");}

function OnE(devt) {JEPost("OnE","OnE="+devt,"NoSet");}
document.addEventListener("DOMContentLoaded", function() {
 JEPost("Status","?v=0","results");
shoDim();
 var wkdy = new Array(7);
 wkdy[0]="ALL";wkdy[1]="SUN";wkdy[2]="MON";wkdy[3]="TUE";wkdy[4]="WED";wkdy[5]="THU";wkdy[6]="FRI";
 wkdy[7]="SAT";wkdy[8]="WDAY";wkdy[9]="WEND";
 var TPk ="<table><tr><th>Day<th>Time<th>Mode<th>Add</tr><tr><TD>"
 TPk=TPk+"<Select id=tday name=tday>";
 for (i = 0; i < 9; i++) {TPk=TPk+"<option value="+i+">"+wkdy[i];}
 TPk = TPk+"</Select>";
 TPk = TPk+"<td><Select id=thr name=thr>";
 TPk=TPk+"<option value=25>Dawn<option value=26>Dusk";
 var plval=0;
 var d = new Date();
 var n = d.getHours();
 var slflg="";
 for (i = 0; i < 24; i++) { 
 slflg="";
   if (i<10) {plval="0";} else {plval="";}
 if (i==n) {slflg="selected";}
   TPk=TPk+"<option "+slflg+">"+plval+i;
 }
 TPk=TPk+"</Select>:<Select id=tmin name=tmin>";
 n = d.getMinutes();
 for (i = 0; i < 60; i++) {
   slflg="";
 if (i==n) {slflg="selected";}
 if (i<10) {plval="0";} else {plval="";}
   TPk=TPk+"<option "+slflg+">"+plval+i;
 }
 document.getElementById("tpick").innerHTML=TPk+"</Select><td><SELECT id=st2 name=st2><OPTION value=0 selected>Off<OPTION value=1 >On</SELECT><TD><button onclick=\"AddEvent()\">+</button></tr></table><p>";
 GetEvent();
 });









