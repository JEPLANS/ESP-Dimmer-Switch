function JEPost(pdest,pdata,pele) {
  var xhttp;
  if (window.XMLHttpRequest) {
	xhttp = new XMLHttpRequest();
  } else {
	xhttp = new ActiveXObject("Microsoft.XMLHTTP"); 
	}
  xhttp.onreadystatechange = function() { if (this.readyState == 4 && this.status == 200) { 
  var D1Sec=this.responseText;
  D1Sec='1440'+D1Sec+',Hour,2,3,4,5,6,7';
  tempGraph(D1Sec,"Lightblue","blue","green",1,pele); ;

 } } ;

  xhttp.open("POST", pdest, true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send(pdata);
}

function GetAll() {
 JEPost("/GDOW","d=1",0) 
 JEPost("/GDOW","d=2",0) 
 JEPost("/GDOW","d=3",0) 
 JEPost("/GDOW","d=4",0) 
 JEPost("/GDOW","d=5",0)
 JEPost("/GDOW","d=6",0) 
 JEPost("/GDOW","d=7",0)
 
}






