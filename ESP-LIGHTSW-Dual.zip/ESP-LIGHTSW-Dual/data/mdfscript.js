function updid(idtup,ipdval) {
  document.getElementById(idtup).innerHTML= ipdval;
  document.getElementById(idtup).value= ipdval;
}

function JEPost(pdest,pdata,pele) {
 var xhttp;
 var trTx;
 if (window.XMLHttpRequest) {
  xhttp = new XMLHttpRequest();
 } else {
   xhttp = new ActiveXObject("Microsoft.XMLHTTP");
 }
 xhttp.onreadystatechange = function() {
 if (this.readyState == 4 && this.status == 200) {
  if(pele != "NoSet"){
   var trTx=this.responseText;
   if (pele=="CrtFilTbl") {
       bldfltb(trTx); 
   } else {
     document.getElementById(pele).innerHTML = trTx; 
   }
   
}}};

  xhttp.open("POST", pdest, true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send(pdata);

  return trTx;

}

function GVL(p1) {
 return encodeURIComponent(document.getElementById(p1).value);
}

function updateSPIFFS() {
 document.getElementById("results").innerHTML = "Updating";
 var pst="Fname=/"+GVL("Fname")+".mcr&Fdata="+GVL("Fdata");
 JEPost("/Config/SPIFFSSave",pst,"results");
}
 
function delMC(pst) {
 document.getElementById("results").innerHTML = "Deleting";
 var pst="Fname=/"+pst+".mcr";
 JEPost("/Config/SPIFFSDel",pst,"lfiles");
}

function lstfls() {
  JEPost("/lfs?fil=.mcr","","CrtFilTbl");
}

function bldfltb( fldt ) {
  flArr = fldt.split(",");
  var fltb="<table border>";

  for (let i = 1; i < flArr.length; i++) {
     var lpf=flArr[i].substring(1,flArr[i].length - 4);
     fltb +="<TR><TD>" +lpf + "<td style=\"cursor: pointer;\" onclick=\"rnMcr(\'"+ lpf +"\')\">⚡<td style=\"cursor: pointer;\" onclick=\"ldMcr(\'"+ lpf +"\')\">✍<td style=\"cursor: pointer;\" onclick=\"delMC(\'"+ lpf +"\')\">&#9851;</TR>";
  }
  fltb +="</table>";
  updid("filesT",fltb);
}

function rnMcr( mtr){
     JEPost("/Macro","MCN="+mtr,"lfiles");
      
}

function ldMcr(mtl){
     updid("lfiles",mtl);
     updid("Fname",mtl);
     JEPost("/dypg","pg=/"+mtl+".mcr","Fdata");
}

