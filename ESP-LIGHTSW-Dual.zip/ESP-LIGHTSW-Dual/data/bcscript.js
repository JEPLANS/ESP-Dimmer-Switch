function JEPost(pdest,pdata,pele) {
  var xhttp;
  if (window.XMLHttpRequest) { xhttp = new XMLHttpRequest();} else { xhttp = new ActiveXObject("Microsoft.XMLHTTP"); }
  xhttp.onreadystatechange = function() { if (this.readyState == 4 && this.status == 200) { if(pele != "NoSet"){
  var trTx=this.responseText;
  document.getElementById(pele).innerHTML = trTx; 
 if (trTx.search("On:")!=-1 || trTx=="On"){
 document.getElementById(pele).classList.remove( "swOff");
 document.getElementById(pele).classList.add( "swOn");
 document.getElementById("st3").value=trTx.substring(3);
 }
 if (trTx.search("Off:")!=-1 || trTx=="Off"){
 document.getElementById(pele).classList.remove( "swOn");
 document.getElementById(pele).classList.add( "swOff");
 document.getElementById("st3").value="0";
 }
  
  } } };
  xhttp.open("POST", pdest, true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send(pdata);
}
function GVL(p1) {
var myEle = document.getElementById(p1);
if(myEle){return myEle.value;} else { return ""; }
}

function Switch() { JEPost("Activate","st2="+GVL("st2")+"&st3="+GVL("st3")+"&sw="+GVL("wsw"),"results");}
function TSwitch(ac) { JEPost("Activate","st2="+ac+"&st3="+GVL("st3")+"&sw="+GVL("wsw"),"results");}
function OSwitch(ac) { JEPost("Activate","st2="+ac+"&st3=100&sw="+GVL("wsw"),"results");}

function shoDim() {
  var x = document.getElementById("dh1");
  if (document.getElementById("swm").value=="1") {
	x.style.display = "none";
     } else {
       x.style.display = "block";
     }
}
function GStts(){
  JEPost("Status","?v=0&sw="+GVL("wsw"),"results");
}



document.addEventListener("DOMContentLoaded", function() {
 JEPost("Status","?v=0","results");
 shoDim();
});












