function JEPost(pdest,pdata,pele) {
  var xhttp;
  if (window.XMLHttpRequest) {
    xhttp = new XMLHttpRequest();
    } else {
    xhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
	if(pele != "NoSet"){
      document.getElementById(pele).innerHTML = this.responseText;
	  }
    }
  };
  xhttp.open("POST", pdest, true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send(pdata);
}

function GVL(p1) {
    return encodeURIComponent(document.getElementById(p1).value);
}

  function updatecfg() {
    var pst="FN="+GVL("FN")+"&LNS="+GVL("LNS");
   for (i = 1; i <= GVL("LNS"); i++) {
	  pst=pst+"&LN"+i+"="+GVL("LN"+i);
	}
    
    JEPost("Config/CFGUPD",pst,"results");
}





